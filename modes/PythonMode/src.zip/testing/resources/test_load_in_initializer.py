#Reformatted for now 
#font = loadFont("data/Cabal1-48.vlw")
def settings():
	size(10, 10, P3D)
	
def setup():
    noLoop()
    print 'OK'
    exit()
